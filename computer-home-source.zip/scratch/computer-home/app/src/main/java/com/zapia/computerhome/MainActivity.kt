package com.zapia.computerhome

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

data class AppEntry(val name: String, val packageName: String, val icon: Drawable)

private val palette = listOf(Color(0xFF111827), Color(0xFF17132B), Color(0xFF081D25), Color(0xFF271416), Color(0xFF171717), Color(0xFF20243A))
private val accents = listOf(Color(0xFF78E7FF), Color(0xFFB69CFF), Color(0xFF67E8A5), Color(0xFFFFC36B), Color(0xFFFF7AA8), Color(0xFFF1F1F1))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { ComputerHome() } }
}

@Composable
private fun ComputerHome() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("computer_home", 0) }
    var setupDone by remember { mutableStateOf(prefs.getBoolean("setup", false)) }
    var bgIndex by remember { mutableIntStateOf(prefs.getInt("bg", 0).coerceIn(palette.indices)) }
    var accentIndex by remember { mutableIntStateOf(prefs.getInt("accent", 0).coerceIn(accents.indices)) }
    var columns by remember { mutableIntStateOf(prefs.getInt("columns", 4).coerceIn(3, 6)) }
    var rounded by remember { mutableStateOf(prefs.getBoolean("rounded", true)) }
    var drawer by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var apps by remember { mutableStateOf(emptyList<AppEntry>()) }
    val recent = remember { mutableStateListOf<String>().apply { addAll(prefs.getString("recent", "")!!.split('|').filter { it.isNotBlank() }.take(8)) } }
    val accent = accents[accentIndex]
    val background = palette[bgIndex]

    LaunchedEffect(Unit) {
        apps = loadApps(context.packageManager).filter { it.packageName != context.packageName }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = accent, onPrimary = Color(0xFF081018), background = background, surface = Color(0xFF141923), onSurface = Color(0xFFF2F5FA))) {
        Box(Modifier.fillMaxSize().background(background)) {
            AnimatedPentagonWallpaper(background, accent)
            if (!setupDone) {
                SetupPage(background, accent, bgIndex, accentIndex, columns, rounded,
                    onBg = { bgIndex = it }, onAccent = { accentIndex = it }, onColumns = { columns = it }, onRounded = { rounded = it },
                    onFinish = {
                        prefs.edit().putBoolean("setup", true).putInt("bg", bgIndex).putInt("accent", accentIndex).putInt("columns", columns).putBoolean("rounded", rounded).apply()
                        setupDone = true
                    })
            } else if (settings) {
                SetupPage(background, accent, bgIndex, accentIndex, columns, rounded,
                    onBg = { bgIndex = it }, onAccent = { accentIndex = it }, onColumns = { columns = it }, onRounded = { rounded = it },
                    onFinish = { prefs.edit().putInt("bg", bgIndex).putInt("accent", accentIndex).putInt("columns", columns).putBoolean("rounded", rounded).apply(); settings = false },
                    onCancel = { settings = false })
            } else if (drawer) {
                DrawerPage(apps, query, recent, accent, rounded, columns,
                    onQuery = { query = it }, onBack = { drawer = false; query = "" },
                    onOpen = { openApp(context, it, recent, prefs); drawer = false; query = "" },
                    onStore = { searchPlayStore(context, query) })
            } else {
                HomePage(apps, recent, accent, columns, rounded,
                    onDrawer = { drawer = true }, onSettings = { settings = true },
                    onOpen = { openApp(context, it, recent, prefs) },
                    onLong = { item ->
                        val dock = prefs.getString("dock", "")!!.split('|').filter { it.isNotBlank() }.toMutableList()
                        if (item.packageName !in dock && dock.size < 5) { dock.add(item.packageName); prefs.edit().putString("dock", dock.joinToString("|")).apply() }
                    },
                    dockIds = prefs.getString("dock", "")!!.split('|').filter { it.isNotBlank() })
            }
        }
    }
}

@Composable
private fun SetupPage(bg: Color, accent: Color, bgIndex: Int, accentIndex: Int, columns: Int, rounded: Boolean,
                      onBg: (Int)->Unit, onAccent:(Int)->Unit, onColumns:(Int)->Unit, onRounded:(Boolean)->Unit,
                      onFinish:()->Unit, onCancel:(()->Unit)?=null) {
    Column(Modifier.fillMaxSize().background(Color(0xEE090C13)).verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Computer Home", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Set up your desktop", color = accent, fontSize = 16.sp)
        Text("Choose your colors", color = Color.White, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { palette.forEachIndexed { i, c -> Swatch(c, bgIndex == i) { onBg(i) } } }
        Text("Accent details", color = Color.White, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { accents.forEachIndexed { i, c -> Swatch(c, accentIndex == i) { onAccent(i) } } }
        Text("Icon grid · $columns columns", color = Color.White, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { (3..6).forEach { n -> FilterChip(selected = columns == n, onClick = { onColumns(n) }, label = { Text("$n") }) } }
        Text("Icon shape", color = Color.White, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = rounded, onClick = { onRounded(true) }, label = { Text("Rounded") })
            FilterChip(selected = !rounded, onClick = { onRounded(false) }, label = { Text("Square") })
        }
        Text("After setup, choose Computer Home as your default Home app in Android settings.", color = Color.LightGray, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (onCancel != null) OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
            Button(onClick = onFinish, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text(if (onCancel == null) "Set up Computer Home" else "Save settings") }
        }
    }
}

@Composable private fun Swatch(color: Color, selected: Boolean, onClick: ()->Unit) {
    Box(Modifier.size(38.dp).clip(CircleShape).background(color).clickable { onClick() }.then(if (selected) Modifier.padding(3.dp) else Modifier), contentAlignment = Alignment.Center) {
        if (selected) Box(Modifier.fillMaxSize().clip(CircleShape).background(color).padding(3.dp))
    }
}

@Composable
private fun HomePage(apps: List<AppEntry>, recent: List<String>, accent: Color, columns: Int, rounded: Boolean, onDrawer:()->Unit, onSettings:()->Unit, onOpen:(AppEntry)->Unit, onLong:(AppEntry)->Unit, dockIds:List<String>) {
    val context = LocalContext.current
    val byId = remember(apps) { apps.associateBy { it.packageName } }
    val dock = dockIds.mapNotNull { byId[it] }.take(5)
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 20.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("Computer Home", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Your desktop", color = accent, fontSize = 13.sp) }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White) }
        }
        Spacer(Modifier.weight(1f))
        val appGrid = remember(apps) { apps.take(12) }
        appGrid.chunked(columns).forEach { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            row.forEach { app -> AppIcon(app, accent, rounded, onClick = { onOpen(app) }, onLong = { onLong(app) }) }
            repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
        }; Spacer(Modifier.height(12.dp)) }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(if (rounded) 24.dp else 8.dp)).background(Color(0xBB111720)).padding(10.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            dock.forEach { app -> AppIcon(app, accent, rounded, compact = true, onClick = { onOpen(app) }, onLong = { onLong(app) }) }
            IconButton(onClick = onDrawer, modifier = Modifier.size(58.dp).background(accent.copy(alpha=.18f), RoundedCornerShape(if (rounded) 18.dp else 4.dp))) { Icon(Icons.Default.Apps, contentDescription = "Open app drawer", tint = accent) }
        }
        Text("Swipe up · App library", color = Color.White.copy(alpha=.8f), fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp))
    }
    var drag by remember { mutableFloatStateOf(0f) }
    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectVerticalDragGestures(onVerticalDrag = { _, d -> drag += d }, onDragEnd = { if (drag < -65) onDrawer(); drag = 0f }) })
}

@Composable
private fun AppIcon(app: AppEntry, accent: Color, rounded: Boolean, compact: Boolean=false, onClick:()->Unit, onLong:()->Unit) {
    val shape = if (rounded) RoundedCornerShape(18.dp) else RoundedCornerShape(4.dp)
    Column(Modifier.width(if (compact) 54.dp else 72.dp).combinedClickable(onClick = onClick, onLongClick = onLong).padding(3.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AndroidIcon(app.icon, Modifier.size(if (compact) 38.dp else 50.dp).clip(shape).background(accent.copy(alpha=.12f)))
        if (!compact) Text(app.name, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable private fun AndroidIcon(drawable: Drawable, modifier: Modifier=Modifier) {
    val bmp = remember(drawable) { runCatching { drawable.toBitmapCompat() }.getOrNull() }
    if (bmp != null) androidx.compose.foundation.Image(bitmap = androidx.compose.ui.graphics.asImageBitmap(bmp), contentDescription = null, modifier = modifier)
    else Box(modifier, contentAlignment = Alignment.Center) { Text("▣", color = Color.White, fontSize = 24.sp) }
}

@Composable
private fun DrawerPage(apps:List<AppEntry>, query:String, recent:List<String>, accent:Color, rounded:Boolean, columns:Int, onQuery:(String)->Unit, onBack:()->Unit, onOpen:(AppEntry)->Unit, onStore:()->Unit) {
    val filtered = apps.filter { it.name.contains(query, true) }.sortedBy { it.name.lowercase() }
    val topRecent = recent.mapNotNull { id -> apps.firstOrNull { it.packageName == id } }
    Column(Modifier.fillMaxSize().background(Color(0xF5090C13)).padding(horizontal = 18.dp, vertical = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Apps", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("Desktop", color = accent) }
        }
        OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search apps") }, leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) })
        if (query.isEmpty() && topRecent.isNotEmpty()) {
            Text("RECENT", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
            Row(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) { topRecent.take(5).forEach { app -> AppIcon(app, accent, rounded, onClick = { onOpen(app) }, onLong = {}) } }
        }
        Text("ALL APPS · A–Z", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(filtered.chunked(columns), key = { row -> row.firstOrNull()?.packageName ?: "empty" }) { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { app ->
                        AppIcon(app, accent, rounded, onClick = { onOpen(app) }, onLong = {})
                    }
                    repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
        if (filtered.isEmpty() && query.isNotBlank()) {
            Text("No app found for ‘$query’", color = Color.White, modifier = Modifier.padding(vertical = 10.dp))
            Button(onClick = onStore, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("Search Play Store") }
        }
    }
}

class LaunchSequenceActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); val pkg = intent.getStringExtra("package") ?: run { finish(); return }; val label = intent.getStringExtra("label") ?: pkg
        setContent { LaunchSequence(label, pkg, onDone = { val launch = packageManager.getLaunchIntentForPackage(pkg); if (launch != null) startActivity(launch); finish() }) }
    }
}

@Composable
private fun LaunchSequence(name:String, packageName:String, onDone:()->Unit) {
    val context = LocalContext.current
    val pm = context.packageManager
    val icon = remember(packageName) { runCatching { pm.getApplicationIcon(packageName) }.getOrNull() }
    val progress by animateFloatAsState(1f, animationSpec = tween(2400, easing = FastOutSlowInEasing), label = "launch")
    val glow by animateFloatAsState(if (progress > .72f) 1f else 0f, animationSpec = tween(400), label = "glow")
    LaunchedEffect(Unit) { delay(3100); onDone() }
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) { if (icon != null) AndroidIcon(icon, Modifier.size(22.dp)); Text("  $name", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                Text("•  •  •", color = Color.LightGray, fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(225.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    drawRoundRect(Color.White, style = Stroke(width = 3.dp.toPx()), cornerRadius = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx()))
                    drawLine(Color.White, Offset(size.width*.38f,size.height*.94f), Offset(size.width*.62f,size.height*.94f), 4.dp.toPx())
                    drawLine(Color.White, Offset(size.width*.50f,size.height*.88f), Offset(size.width*.50f,size.height*.94f), 3.dp.toPx())
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (icon != null) AndroidIcon(icon, Modifier.size((52+progress*30).dp)) else Text("▣", color=Color.White, fontSize=56.sp)
                    Text(name, color=Color.White, fontSize=17.sp, fontWeight=FontWeight.Bold)
                }
                if (glow > .3f) Canvas(Modifier.fillMaxSize()) {
                    val random = Random(packageName.hashCode())
                    repeat(80) { i ->
                        val angle = i * (6.28318f / 80f)
                        val radius = (size.minDimension * (.10f + progress*.42f)) * (0.5f + random.nextFloat())
                        drawCircle(Color(0xFFBCEEFF).copy(alpha = (glow * (1f-progress*.5f)).coerceIn(0f,1f)), (1.5f+random.nextFloat()*2.5f).dp.toPx(), Offset(size.width*.5f+cos(angle)*radius,size.height*.47f+sin(angle)*radius))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            ComputerKeyboard(name, accent = Color(0xFF8BEAFF), glow = progress)
            Spacer(Modifier.height(8.dp))
            Text("Starting $name", color=Color.White.copy(alpha=.75f), fontSize=13.sp)
        }
    }
}

@Composable private fun ComputerKeyboard(name:String, accent:Color, glow:Float) {
    val rows=listOf("QWERTYUIOP","ASDFGHJKL","ZXCVBNM")
    Column(Modifier.fillMaxWidth().background(Color(0xFF0A0D13), RoundedCornerShape(12.dp)).padding(8.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        rows.forEach { row -> Row(horizontalArrangement=Arrangement.spacedBy(3.dp), verticalAlignment=Alignment.CenterVertically) {
            row.forEach { ch -> val lit = name.uppercase().contains(ch) && glow > .22f
                Box(Modifier.weight(1f).height(25.dp).background(if(lit) accent.copy(alpha=.9f) else Color(0xFF202633), RoundedCornerShape(4.dp)), contentAlignment=Alignment.Center) { Text(ch.toString(), fontSize=10.sp, color=if(lit) Color.Black else Color.LightGray, fontWeight=FontWeight.Bold) }
            }
        }; Spacer(Modifier.height(4.dp)) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp), verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.weight(5f).height(25.dp).background(Color(0xFF202633), RoundedCornerShape(4.dp)))
            Box(Modifier.weight(1f).height(28.dp).background(Color(0xFF111720), RoundedCornerShape(8.dp)), contentAlignment=Alignment.Center) { Text("⌖", color=accent, fontSize=18.sp) }
        }
    }
}

@Composable
private fun AnimatedPentagonWallpaper(background:Color, accent:Color) {
    val infinite = rememberInfiniteTransition(label="pentagon")
    val phase by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing=LinearEasing), RepeatMode.Restart), label="phase")
    Canvas(Modifier.fillMaxSize()) {
        val center=Offset(size.width*.5f,size.height*.47f); val base=size.minDimension*.16f
        val grow=if(phase<.58f) phase/.58f else (1f-(phase-.58f)/.42f).coerceAtLeast(0f)
        val r=base*(.28f+grow*.8f)
        val path=Path(); for(i in 0..4){ val angle=(-Math.PI/2+i*2*Math.PI/5).toFloat(); val point=Offset(center.x+cos(angle)*r,center.y+sin(angle)*r); if(i==0)path.moveTo(point.x,point.y) else path.lineTo(point.x,point.y) }; path.close()
        val alpha=(1f-phase/.7f).coerceIn(0f,.45f)
        drawPath(path,accent.copy(alpha=alpha),style=Stroke(width=3.dp.toPx()))
        if(phase>.55f){ repeat(32){i-> val a=i*6.28318f/32; val dist=base*(.2f+(phase-.55f)*2f)*(1f+(i%4)*.1f); drawCircle(accent.copy(alpha=(1f-phase).coerceIn(0f,.8f)),(1.5f+(i%3)).dp.toPx(),Offset(center.x+cos(a)*dist,center.y+sin(a)*dist)) } }
    }
}

private fun loadApps(pm:PackageManager):List<AppEntry> = try {
    val intent=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(intent,0).mapNotNull { info ->
        val ai=info.activityInfo.applicationInfo
        runCatching { AppEntry(pm.getApplicationLabel(ai).toString(),ai.packageName,pm.getApplicationIcon(ai)) }.getOrNull()
    }.distinctBy { it.packageName }.sortedBy { it.name.lowercase() }
} catch (_:Exception) { emptyList() }

private fun openApp(activity:android.content.Context, app:AppEntry, recent:MutableList<String>, prefs:android.content.SharedPreferences) {
    recent.remove(app.packageName); recent.add(0,app.packageName); while(recent.size>8)recent.removeAt(recent.lastIndex)
    prefs.edit().putString("recent",recent.joinToString("|")).apply()
    activity.startActivity(Intent(activity,LaunchSequenceActivity::class.java).putExtra("package",app.packageName).putExtra("label",app.name))
}
private fun searchPlayStore(context:android.content.Context, q:String) {
    val encoded=Uri.encode(q)
    val market=Intent(Intent.ACTION_VIEW,Uri.parse("market://search?q=$encoded"))
    try { context.startActivity(market) } catch (_:Exception) { context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/search?q=$encoded&c=apps"))) }
}

private fun Drawable.toBitmapCompat(): android.graphics.Bitmap {
    val width=drawable.intrinsicWidth.coerceAtLeast(1); val height=drawable.intrinsicHeight.coerceAtLeast(1)
    val bitmap=android.graphics.Bitmap.createBitmap(width,height,android.graphics.Bitmap.Config.ARGB_8888)
    val canvas=android.graphics.Canvas(bitmap); drawable.setBounds(0,0,width,height); drawable.draw(canvas); return bitmap
}
